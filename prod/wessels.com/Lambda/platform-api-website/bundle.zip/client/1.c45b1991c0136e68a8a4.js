webpackJsonp([1],{

/***/ 548:
/***/ (function(module, exports) {

module.exports = {
	"demoTitle": "Preact Material Design Components Web (preact-mdc) [visa/de]"
};

/***/ })

});
//# sourceMappingURL=1.c45b1991c0136e68a8a4.js.map