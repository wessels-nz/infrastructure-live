webpackJsonp([1],{548:function(e,t){e.exports={demoTitle:"Preact Material Design Components Web (preact-mdc) [visa/de]"}}});
//# sourceMappingURL=1.a877bc6b434f87df8d3a.js.map